import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { DashboardActionsComponent } from './components/dashboard-actions/dashboard-actions.component';
import { EducationComponent } from './components/education/education.component';
import { ExperienceComponent } from './components/experience/experience.component';
import { httpInterceptorProviders } from '../core/interceptors';
import { EditProfileComponent } from '../profile-forms/components/edit-profile/edit-profile.component';

@NgModule({
  declarations: [
    DashboardComponent,
    DashboardActionsComponent,
    EducationComponent,
    ExperienceComponent,
  ],
  imports: [CommonModule, DashboardRoutingModule],
  providers: [httpInterceptorProviders],
})
export class DashboardModule {}
