import { AddEducation } from './add-education';

describe('AddEducation', () => {
  it('should create an instance', () => {
    expect(new AddEducation()).toBeTruthy();
  });
});
