import { AddExperience } from './add-experience';

describe('AddExperience', () => {
  it('should create an instance', () => {
    expect(new AddExperience()).toBeTruthy();
  });
});
