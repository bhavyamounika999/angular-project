import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProfileAboutComponent } from './components/profile-about/profile-about.component';
import { ProfileEducationComponent } from './components/profile-education/profile-education.component';
import { ProfileExperienceComponent } from './components/profile-experience/profile-experience.component';
import { ProfileGithubComponent } from './components/profile-github/profile-github.component';
import { ProfileTopComponent } from './components/profile-top/profile-top.component';
import { ProfileComponent } from './components/profile/profile.component';

const routes: Routes = [
  {
    path: 'profile',
    component: ProfileComponent,
  },
  {
    path: 'profile-about',
    component: ProfileAboutComponent,
  },
  {
    path: 'profile-education',
    component: ProfileEducationComponent,
  },
  {
    path: 'profile-experience',
    component: ProfileExperienceComponent,
  },
  {
    path: 'profile-github',
    component: ProfileGithubComponent,
  },
  {
    path: 'profile-top',
    component: ProfileTopComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ProfileRoutingModule {}
