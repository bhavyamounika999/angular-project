import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ProfileServicesService {
  constructor(private http: HttpClient) {}

  createProfile(data: any): Observable<any> {
    return this.http.post('/api/profile', data);
  }

  getProfile(): Observable<any> {
    return this.http.get('/api/profile/me');
  }

  editProfile(data: any): Observable<any> {
    return this.http.post('/api/profile', data);
  }

  addExperience(data: any): Observable<any> {
    return this.http.put('/api/profile/experience', data);
  }

  addEducation(data: any): Observable<any> {
    return this.http.put('/api/profile/education', data);
  }
}
