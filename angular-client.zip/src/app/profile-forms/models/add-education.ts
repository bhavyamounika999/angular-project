export class AddEducation {
  school: String;
  degree: String;
  fieldofstudy: String;
  from: Date;
  to: Date;
  current: boolean;
  description: String;
}
