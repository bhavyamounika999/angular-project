export class CreateProfile {
  company: String;
  website: String;
  location: String;
  status: String;
  skills: String;
  githubusername: String;
  bio: String;
  twitter: String;
  facebook: String;
  linkedin: String;
  youtube: String;
  instagram: String;
}
