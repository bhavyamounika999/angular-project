export class AddExperience {
  company: String;
  title: String;
  location: String;
  from: Date;
  to: Date;
  current: Boolean;
  description: String;
}
