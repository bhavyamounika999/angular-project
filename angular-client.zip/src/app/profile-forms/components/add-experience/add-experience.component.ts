import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AddExperience } from '../../models/add-experience';
import { AddExperienceService } from '../../services/add-experience.service';

@Component({
  selector: 'app-add-experience',
  templateUrl: './add-experience.component.html',
  styleUrls: ['./add-experience.component.css'],
})
export class AddExperienceComponent implements OnInit {
  addExperience: AddExperience = new AddExperience();

  constructor(
    private addExperienceService: AddExperienceService,
    private router: Router
  ) {}

  addExperienceSubmit() {
    this.addExperienceService.addExperience(this.addExperience).subscribe(
      (res) => {
        console.log('added experience');
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        console.log(JSON.stringify(err));
      }
    );
  }

  ngOnInit(): void {}
}
