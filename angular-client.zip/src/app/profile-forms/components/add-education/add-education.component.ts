import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AddEducation } from '../../models/add-education';
import { AddEducationService } from '../../services/add-education.service';

@Component({
  selector: 'app-add-education',
  templateUrl: './add-education.component.html',
  styleUrls: ['./add-education.component.css'],
})
export class AddEducationComponent implements OnInit {
  addEducation: AddEducation = new AddEducation();

  constructor(
    private addEducationService: AddEducationService,
    private router: Router
  ) {}

  addEducationSubmit() {
    this.addEducationService.addEducation(this.addEducation).subscribe(
      (res) => {
        console.log('added education');
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        console.log(JSON.stringify(err));
      }
    );
  }

  ngOnInit(): void {}
}
