import { CommentForm } from './comment-form';

describe('CommentForm', () => {
  it('should create an instance', () => {
    expect(new CommentForm()).toBeTruthy();
  });
});
