import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { DashboardActionsComponent } from './components/dashboard-actions/dashboard-actions.component';
import { EducationComponent } from './components/education/education.component';
import { ExperienceComponent } from './components/experience/experience.component';
import { httpInterceptorProviders } from '../core/interceptors';
import { CreateProfileService } from '../profile-forms/services/create-profile.service';
import { EditProfileService } from '../profile-forms/services/edit-profile.service';
import { AddEducationService } from '../profile-forms/services/add-education.service';
import { AddExperienceService } from '../profile-forms/services/add-experience.service';
import { CoreModule } from '../core/core.module';
import { EducationItemComponent } from './components/education-item/education-item.component';
import { ExperienceItemComponent } from './components/experience-item/experience-item.component';
import { AuthService } from '../auth/services/auth.service';
import { ProfileServicesService } from '../profile-forms/services/profile-services.service';

@NgModule({
  declarations: [
    DashboardComponent,
    DashboardActionsComponent,
    EducationComponent,
    ExperienceComponent,
    EducationItemComponent,
    ExperienceItemComponent,
  ],
  providers: [httpInterceptorProviders, AuthService, ProfileServicesService],
  imports: [CommonModule, DashboardRoutingModule, HttpClientModule, CoreModule],
})
export class DashboardModule {}
