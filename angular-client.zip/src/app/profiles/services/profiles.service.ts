import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ProfilesService {
  constructor(private http: HttpClient) {}

  showProfiles(): Observable<any> {
    return this.http.get('/api/profiles');
  }
  loadProfiles(): Observable<any> {
    return this.http.get('/api/profile');
  }

  // showProfileById(): Observable<any> {
  //   return this.http.get('/api/profile/user:user_id');
  // }
}
