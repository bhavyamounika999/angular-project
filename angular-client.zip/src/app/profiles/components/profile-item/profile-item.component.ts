import { Component, Input, OnInit } from '@angular/core';
import { Profile } from '../../models/profile';
import { ProfilesService } from '../../services/profiles.service';

@Component({
  selector: 'app-profile-item',
  templateUrl: './profile-item.component.html',
  styleUrls: ['./profile-item.component.css'],
})
export class ProfileItemComponent implements OnInit {
  constructor(private profileService: ProfilesService) {}
  @Input() profile: Profile;

  ngOnInit(): void {}
}
