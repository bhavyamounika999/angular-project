import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profiles-item',
  templateUrl: './profiles-item.component.html',
  styleUrls: ['./profiles-item.component.css']
})
export class ProfilesItemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
