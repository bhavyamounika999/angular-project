export class User {
  _id: string;
  name: string;
}
export class Profile extends User {
  user: User;
  status: string;
  company: string;
  location: string;
  skills: string;
}
