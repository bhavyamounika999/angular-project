export class Register {
  name: String;
  email: String;
  password: String;
  password2: String;
}
