import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Register } from '../../models/register';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  register: Register = new Register();

  constructor(private authService: AuthService, private router: Router) {}

  registerSubmit() {
    console.log(JSON.stringify(this.register));

    const newUser: any = {
      name: this.register.name,
      email: this.register.email,
      password: this.register.password,
    };
    // Here in subscribe we have two things success and failure part (sucess is then part and failure is catch part according to axios)
    this.authService.registerUser(newUser).subscribe(
      (res) => {
        console.log('User registered successfully');
        this.router.navigate(['/dashboard']);
        console.log(JSON.stringify(res)); //if login->success --->generates a token=>prints token
        localStorage.setItem('token', res.token);
      },
      (err) => {}
    );
  }
  ngOnInit(): void {}
}
